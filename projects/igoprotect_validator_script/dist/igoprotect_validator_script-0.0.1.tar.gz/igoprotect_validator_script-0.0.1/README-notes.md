# Validator script


## Functionality

### Configuration

### Contract maintenance

#### Generate and deposit keys
- Generate partkey on the node.
- Deposit the partkey to the delegator contract.

#### Delete unconfirmed keys and delegator contracts
- Delete partkeys.
- Delete delegator contract.

#### Delete expired delegator contracts
- Delete expired contracts (try deleting partkeys).

#### Delete keys of withdrawn contracts
- Delete partkeys wihtout for the delegators who's contracts were withdrawn (deleted).
This point requires managing the state of the validator locally, hence will require storing the state in a local file(?) to use as a starting point upon re-running the script.
- Additionally, this state can be used in cases where a partkey is generated, while its depositing fails on the first try - on the retry, the previously-generated key is used.


## To-Do

### Delegator contract breached

1. Check if breached
2. Take non-deletion action
3. Delete contract


### Delegator contract withdrawn

1. Check if each partkey has a delegator contract associated with the validator app.
2. Delete the keys that do not have a contract counterpart.


 ### Unit tests

 - Cover as many of the validator functionalities using unittests.
 - This includes setting up the required contracts, hence, pointing to the i-go-protect directory even if the validator will be moved to a separate development directory in the future.


 ### Error handling

- Have at least a means of try-except in place for handling errors.
- What solutions are there to allow users to submit error tickets?


### Reduce logging amount and include log setup in config

- Include log filepath in config(?).
- Change the recurrent 'info' to 'debug'.
- Include log level selection in the config.


### Add config type and format checking

- The config is based on node runner input, which might be ... buggy
- Add type and format (length?) checking in order to provide the node runner with immediate debug feedback


### Automate build process

The validator script relies on some smart contract artifacts.
These are currently manually migrated to the script's source.
A bash script is required to automatically copy and rename these, before activating the Python env and building the wheel.
