from .validator_script import main
